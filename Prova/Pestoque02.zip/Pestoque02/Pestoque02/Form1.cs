﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace Pestoque02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] entrada = new int[4, 4];
            int produto, semana,TotalTudo = 0;
            string auxiliar = "";

            for (produto = 0; produto < 4; produto++)
            {
                int total = 0;
                int totalMes = 0;
                for ( semana = 0; semana < 4; semana++)
                {
                    auxiliar = Interaction.InputBox($"Digite o numero de entradas do produto {produto + 1} da semana {semana + 1}");
                    if (!int.TryParse(auxiliar, out entrada[semana, produto]) || int.Parse(auxiliar) < 0)
                    {
                        MessageBox.Show("Numero invalido");
                        produto--;
                    }
                    else
                    {
                        lbEntradaProd.Items.Add($"Total de entradas do produto {produto + 1} semana {semana + 1}: {auxiliar}");
                        totalMes += int.Parse(auxiliar);
                        total += int.Parse(auxiliar);

                    }
                }
                
                lbEntradaProd.Items.Add($"Total de entradas do produto {produto + 1}: {total}");
                TotalTudo += totalMes;
            }
            lbEntradaProd.Items.Add($"Total geral entradas: {TotalTudo}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbEntradaProd.Items.Clear();
        }
    }
}
