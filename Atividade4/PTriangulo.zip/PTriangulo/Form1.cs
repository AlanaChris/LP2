﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        Double valorA, valorB, valorC;

        private void txtValorB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out valorB))
            {
                MessageBox.Show("Valor invalido");
                e.Cancel = true;
            }
            else if (valorB <= 0)
            {
                MessageBox.Show("Valor deve ser maior que zero");
                e.Cancel = true;
            }
        }

        private void txtValorC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out valorC))
            {
                MessageBox.Show("Valor invalido");
                e.Cancel = true;
            }
            else if (valorC <= 0)
            {
                MessageBox.Show("Valor deve ser maior que zero");
                e.Cancel = true;
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((valorA < valorB + valorC) && (valorA > Math.Abs(valorB - valorC)) && 
                (valorB < valorA + valorC) && (valorB > Math.Abs(valorA - valorC)) &&
                (valorC < valorB + valorA) && (valorC > Math.Abs(valorB - valorA)))
            { 
                if ((valorA == valorB) && (valorC == valorB)) 
                {
                    MessageBox.Show("Triângulo equilátero");
                }
                else if ((valorA == valorB) || (valorC == valorB) || (valorA == valorC))
                {
                    MessageBox.Show("Triângulo isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os valores informados não formam um triângulo :(");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();  
            txtValorC.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorA.Text, out valorA))
            {
                MessageBox.Show("Valor invalido");
                e.Cancel = true;    
            }
            else if (valorA <= 0)
            {
                MessageBox.Show("Valor deve ser maior que zero");
                e.Cancel = true;    
            }
        }
    }
}
