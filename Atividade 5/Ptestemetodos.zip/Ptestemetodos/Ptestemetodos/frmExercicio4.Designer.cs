﻿namespace Ptestemetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContarNumeros = new System.Windows.Forms.Button();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(213, 37);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(457, 169);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContarNumeros
            // 
            this.btnContarNumeros.Location = new System.Drawing.Point(111, 275);
            this.btnContarNumeros.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnContarNumeros.Name = "btnContarNumeros";
            this.btnContarNumeros.Size = new System.Drawing.Size(159, 75);
            this.btnContarNumeros.TabIndex = 1;
            this.btnContarNumeros.Text = "Contar numeros";
            this.btnContarNumeros.UseVisualStyleBackColor = true;
            this.btnContarNumeros.Click += new System.EventHandler(this.btnContarNumeros_Click);
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(363, 275);
            this.btnEspacoBranco.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(150, 75);
            this.btnEspacoBranco.TabIndex = 2;
            this.btnEspacoBranco.Text = "Primeiro espaço em branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Location = new System.Drawing.Point(624, 275);
            this.btnContarLetras.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(150, 75);
            this.btnContarLetras.TabIndex = 3;
            this.btnContarLetras.Text = "Contar letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.btnContarNumeros);
            this.Controls.Add(this.rchtxtFrase);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContarNumeros;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnContarLetras;
    }
}