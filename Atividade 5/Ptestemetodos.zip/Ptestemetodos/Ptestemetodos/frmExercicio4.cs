﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContarNumeros_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtFrase.Text.Length;
            int contaNumero = 0;
            int i = 0;
            while (i < tamanho)
            {
                if (Char.IsNumber(rchtxtFrase.Text[i]))
                {
                    contaNumero++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de números: {contaNumero}");
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (var i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i;
                    break;
                }
            }
            if(posicao== -1)
            {
                MessageBox.Show("Não existe espaço em branco");
            }
            else
            MessageBox.Show($"Posição 1º espaço branco: {posicao}");
        }

        private void btnContarLetras_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtFrase.Text.Length;
            int contaLetras = 0;
            int i = 0;
            while (i < tamanho)
            {
                if (Char.IsLetter(rchtxtFrase.Text[i]))
                {
                    contaLetras++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de letras: {contaLetras}");
        }
    }
}
