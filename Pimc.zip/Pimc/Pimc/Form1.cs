﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        Double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxPeso.Text, out peso) ||
                peso <= 0)
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            }

        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxAltura.Text, out altura) ||
                altura<=0)
            {
                MessageBox.Show("Altura inválida");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            txtIMC.Text = imc.ToString("N1");   
            imc = Math.Round(imc,1);

            if(imc < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else
            {
                if(imc < 25)
                {
                    MessageBox.Show("Normal");
                }
                else
                {
                    if (imc < 30)
                    {
                        MessageBox.Show("Sobrepeso");
                    }
                    else
                    {
                        if (imc < 40)
                        {
                            MessageBox.Show("Obseidade");
                        }
                        else
                        {
                            MessageBox.Show("Obesidade grave");
                        }
                    }
                }

            }
        }
    }
}
