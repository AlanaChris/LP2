﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click_1(object sender, EventArgs e)
        {
            String[] listaNomes = new String[10];
            string auxiliar = "", auxiliar2 = "";
            int numCarac = 0;

            for (int nome = 0; nome < 10; nome++)
            {
                auxiliar = Interaction.InputBox($"Digite o {nome + 1}º nome:");
                if(string.IsNullOrEmpty(auxiliar))
                {
                    lbNomes.Items.Add("Nome invalido");
                }
                auxiliar2 = auxiliar.Replace(" ", "");
                numCarac = auxiliar2.Length;
                lbNomes.Items.Add($"O nome {auxiliar} tem {numCarac} caracteres");
            }
        }
    }
}
