﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vet = new int[20];
            string auxiliar = " ";
            string saida = " ";
            for(int i = 0; i < vet.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}° número","Entrada de dados");

                if (!int.TryParse(auxiliar, out vet[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
                else
                {
                    saida = auxiliar + "\n" + saida;
                    MessageBox.Show(saida);
                }

            }

            Array.Reverse(vet);
            auxiliar = "";

            foreach(int i in vet)
            {
                auxiliar += i + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList listaAlunos = new ArrayList();
            listaAlunos.Add("Ana");
            listaAlunos.Add("André");
            listaAlunos.Add("Débora");
            listaAlunos.Add("Fátima");
            listaAlunos.Add("João");
            listaAlunos.Add("Janete");
            listaAlunos.Add("Otávio");
            listaAlunos.Add("Marcelo");
            listaAlunos.Add("Pedro");
            listaAlunos.Add("Thais");

            listaAlunos.Remove("Otávio");

            foreach(string alunos in listaAlunos) {
                MessageBox.Show(alunos);
            }
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            Double media, somaNotas;
            string auxiliar = "";
            for(int aluno = 0; aluno < 20; aluno++) {
                media = 0;
                somaNotas = 0;

                for(int notaIndv = 0; notaIndv < 3; notaIndv++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {aluno + 1}º:", "Médias");

                    if (!Double.TryParse(auxiliar, out notas[aluno, notaIndv]) || notas[aluno, notaIndv] > 10 || notas[aluno, notaIndv] < 0)
                    {
                        MessageBox.Show("Nota inválida");
                        notaIndv--;
                    }
                    else
                    {
                        somaNotas += notas[aluno, notaIndv];
                    }

                    media = somaNotas / 3;
                }

                MessageBox.Show(media.ToString("F2"), $"Média do {aluno + 1}º aluno é:");
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 frm = new frmExercicio4();
            frm.ShowDialog();

        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 frm = new frmExercicio5();
            frm.ShowDialog();
        }
    }
}
